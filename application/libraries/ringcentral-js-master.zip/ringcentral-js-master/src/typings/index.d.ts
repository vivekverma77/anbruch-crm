/// <reference path="globals/karma/index.d.ts" />
/// <reference path="globals/mocha/index.d.ts" />
/// <reference path="globals/whatwg-fetch/index.d.ts" />
/// <reference path="modules/chai/index.d.ts" />
/// <reference path="modules/fetch-mock/index.d.ts" />
/// <reference path="modules/sinon-chai/index.d.ts" />
/// <reference path="modules/sinon/index.d.ts" />
