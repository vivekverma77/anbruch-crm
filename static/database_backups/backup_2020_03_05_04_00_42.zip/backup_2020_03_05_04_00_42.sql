#
# TABLE STRUCTURE FOR: anb_crm_activities
#

DROP TABLE IF EXISTS `anb_crm_activities`;

CREATE TABLE `anb_crm_activities` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `record_id` int(11) DEFAULT NULL,
  `google_event_id` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(255) NOT NULL DEFAULT '',
  `due_date` date NOT NULL,
  `assigned_officer_id` int(11) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT '',
  `priority` varchar(255) NOT NULL DEFAULT '',
  `closed_time` date DEFAULT NULL,
  `notification_time` date DEFAULT NULL,
  `created_time` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_time` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

INSERT INTO `anb_crm_activities` (`id`, `record_id`, `google_event_id`, `name`, `type`, `due_date`, `assigned_officer_id`, `status`, `priority`, `closed_time`, `notification_time`, `created_time`, `created_by`, `modified_time`, `modified_by`) VALUES (2, 1, '', 'Email the client', 'Task', '2018-08-11', 2, 'Not Started', 'High', '2018-08-10', NULL, 1533824478, 1, 1533977058, 1);
INSERT INTO `anb_crm_activities` (`id`, `record_id`, `google_event_id`, `name`, `type`, `due_date`, `assigned_officer_id`, `status`, `priority`, `closed_time`, `notification_time`, `created_time`, `created_by`, `modified_time`, `modified_by`) VALUES (3, 173, '', 'testing', 'Call', '2018-09-28', 20, 'In Progress', 'High', '2018-10-12', NULL, 1537795945, 1, 1548156359, 1);
INSERT INTO `anb_crm_activities` (`id`, `record_id`, `google_event_id`, `name`, `type`, `due_date`, `assigned_officer_id`, `status`, `priority`, `closed_time`, `notification_time`, `created_time`, `created_by`, `modified_time`, `modified_by`) VALUES (4, 173, '', 'TEST Vilkas', 'Task', '2018-09-29', 2, 'In Progress', 'Highest', NULL, NULL, 1538207013, 1, NULL, NULL);
INSERT INTO `anb_crm_activities` (`id`, `record_id`, `google_event_id`, `name`, `type`, `due_date`, `assigned_officer_id`, `status`, `priority`, `closed_time`, `notification_time`, `created_time`, `created_by`, `modified_time`, `modified_by`) VALUES (5, 173, '', 'first activity now', 'Task', '2018-09-29', 3, 'In Progress', 'High', '0000-00-00', NULL, 1538214604, 1, 1538214639, 1);
INSERT INTO `anb_crm_activities` (`id`, `record_id`, `google_event_id`, `name`, `type`, `due_date`, `assigned_officer_id`, `status`, `priority`, `closed_time`, `notification_time`, `created_time`, `created_by`, `modified_time`, `modified_by`) VALUES (6, 175, '', 'wednes lead', 'Task', '2018-10-18', 3, 'In Progress', 'High', NULL, NULL, 1538538501, 1, NULL, NULL);
INSERT INTO `anb_crm_activities` (`id`, `record_id`, `google_event_id`, `name`, `type`, `due_date`, `assigned_officer_id`, `status`, `priority`, `closed_time`, `notification_time`, `created_time`, `created_by`, `modified_time`, `modified_by`) VALUES (7, 176, '', 'draw activity', 'Task', '2018-10-28', 9, 'Not Started', 'High', NULL, NULL, 1538738852, 10, NULL, NULL);
INSERT INTO `anb_crm_activities` (`id`, `record_id`, `google_event_id`, `name`, `type`, `due_date`, `assigned_officer_id`, `status`, `priority`, `closed_time`, `notification_time`, `created_time`, `created_by`, `modified_time`, `modified_by`) VALUES (8, 178, '', 'won activity', 'Task', '2018-10-25', 10, 'Not Started', 'High', NULL, NULL, 1538738936, 1, NULL, NULL);
INSERT INTO `anb_crm_activities` (`id`, `record_id`, `google_event_id`, `name`, `type`, `due_date`, `assigned_officer_id`, `status`, `priority`, `closed_time`, `notification_time`, `created_time`, `created_by`, `modified_time`, `modified_by`) VALUES (9, 192, '', 'normal activity', 'Task', '2018-10-28', 10, 'Not Started', 'Low', NULL, NULL, 1538739080, 10, NULL, NULL);
INSERT INTO `anb_crm_activities` (`id`, `record_id`, `google_event_id`, `name`, `type`, `due_date`, `assigned_officer_id`, `status`, `priority`, `closed_time`, `notification_time`, `created_time`, `created_by`, `modified_time`, `modified_by`) VALUES (11, 36472, '', 'test ravi activity', 'Event', '2018-12-30', 1, 'In Progress', 'Normal', '0000-00-00', NULL, 1546065324, 1, 1561020477, 1);
INSERT INTO `anb_crm_activities` (`id`, `record_id`, `google_event_id`, `name`, `type`, `due_date`, `assigned_officer_id`, `status`, `priority`, `closed_time`, `notification_time`, `created_time`, `created_by`, `modified_time`, `modified_by`) VALUES (14, 36585, '', 'RISHI RAJ RAI', 'Task', '2019-01-15', 3, 'In Progress', 'High', '0000-00-00', NULL, 1547553248, 1, 1547553342, 1);
INSERT INTO `anb_crm_activities` (`id`, `record_id`, `google_event_id`, `name`, `type`, `due_date`, `assigned_officer_id`, `status`, `priority`, `closed_time`, `notification_time`, `created_time`, `created_by`, `modified_time`, `modified_by`) VALUES (15, 36584, '', 'RISHI RAJ RAI', 'Event', '2019-01-16', 1, 'Deferred', 'Highest', '0000-00-00', NULL, 1547553581, 1, 1547558741, 1);
INSERT INTO `anb_crm_activities` (`id`, `record_id`, `google_event_id`, `name`, `type`, `due_date`, `assigned_officer_id`, `status`, `priority`, `closed_time`, `notification_time`, `created_time`, `created_by`, `modified_time`, `modified_by`) VALUES (19, 13945, '', 'Testing', 'Call', '2019-03-06', 30, 'In Progress', 'High', NULL, NULL, 1551769782, 1, NULL, NULL);
INSERT INTO `anb_crm_activities` (`id`, `record_id`, `google_event_id`, `name`, `type`, `due_date`, `assigned_officer_id`, `status`, `priority`, `closed_time`, `notification_time`, `created_time`, `created_by`, `modified_time`, `modified_by`) VALUES (16, 36592, '', 'mvb', 'Event', '2019-01-15', 1, 'In Progress', 'High', '2019-01-18', NULL, 1547558879, 1, 1547617417, 1);
INSERT INTO `anb_crm_activities` (`id`, `record_id`, `google_event_id`, `name`, `type`, `due_date`, `assigned_officer_id`, `status`, `priority`, `closed_time`, `notification_time`, `created_time`, `created_by`, `modified_time`, `modified_by`) VALUES (17, 36592, '', 'ash', 'Task', '2019-01-17', 20, 'Not Started', 'High', '0000-00-00', NULL, 1547618418, 1, 1547648538, 1);
INSERT INTO `anb_crm_activities` (`id`, `record_id`, `google_event_id`, `name`, `type`, `due_date`, `assigned_officer_id`, `status`, `priority`, `closed_time`, `notification_time`, `created_time`, `created_by`, `modified_time`, `modified_by`) VALUES (20, 13945, '', 'Testing', 'Call', '2019-03-06', 30, 'In Progress', 'High', NULL, NULL, 1551770654, 1, NULL, NULL);
INSERT INTO `anb_crm_activities` (`id`, `record_id`, `google_event_id`, `name`, `type`, `due_date`, `assigned_officer_id`, `status`, `priority`, `closed_time`, `notification_time`, `created_time`, `created_by`, `modified_time`, `modified_by`) VALUES (21, 13945, '', 'Testing', 'Call', '2019-03-06', 30, 'In Progress', 'High', NULL, NULL, 1551770661, 1, NULL, NULL);
INSERT INTO `anb_crm_activities` (`id`, `record_id`, `google_event_id`, `name`, `type`, `due_date`, `assigned_officer_id`, `status`, `priority`, `closed_time`, `notification_time`, `created_time`, `created_by`, `modified_time`, `modified_by`) VALUES (22, 13945, '', 'Test', 'Call', '2019-03-06', 1, 'In Progress', 'High', NULL, NULL, 1551963142, 1, NULL, NULL);
INSERT INTO `anb_crm_activities` (`id`, `record_id`, `google_event_id`, `name`, `type`, `due_date`, `assigned_officer_id`, `status`, `priority`, `closed_time`, `notification_time`, `created_time`, `created_by`, `modified_time`, `modified_by`) VALUES (23, 13945, '', 'Test', 'Call', '2019-03-06', 1, 'In Progress', 'High', NULL, NULL, 1551963201, 1, NULL, NULL);


#
# TABLE STRUCTURE FOR: anb_crm_modules
#

DROP TABLE IF EXISTS `anb_crm_modules`;

CREATE TABLE `anb_crm_modules` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `singular_name` varchar(255) NOT NULL DEFAULT '',
  `plural_name` varchar(255) NOT NULL DEFAULT '',
  `visibility` tinyint(1) NOT NULL DEFAULT '1',
  `serial` tinyint(4) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `anb_crm_modules` (`id`, `singular_name`, `plural_name`, `visibility`, `serial`, `created_by`, `created_time`) VALUES (1, 'Lead', 'Leads', 1, 1, 1, 1531049836);
INSERT INTO `anb_crm_modules` (`id`, `singular_name`, `plural_name`, `visibility`, `serial`, `created_by`, `created_time`) VALUES (2, 'Client', 'Clients', 1, 2, 1, 1531049836);
INSERT INTO `anb_crm_modules` (`id`, `singular_name`, `plural_name`, `visibility`, `serial`, `created_by`, `created_time`) VALUES (3, 'Contract', 'Contracts', 1, 3, 1, 1531049836);


